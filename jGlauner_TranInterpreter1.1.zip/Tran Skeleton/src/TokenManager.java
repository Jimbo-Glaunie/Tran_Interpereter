import java.util.List;
import java.util.Optional;

public class TokenManager {

    List<Token> tokens;






    public TokenManager(List<Token> tokens) {
        this.tokens = tokens;
        int i=1;
        while(i<tokens.size()){
            while(i<tokens.size()&&tokens.get(i).getType().equals(Token.TokenTypes.INDENT)&&tokens.get(i-1).getType().equals(Token.TokenTypes.INDENT)){
                tokens.remove(i);
            }
            i++;
        }
        i=1;
//        while(i<tokens.size()){
//            while(i<tokens.size()&&nextTwoTokensMatch(Token.TokenTypes.INDENT, Token.TokenTypes.NEWLINE)){
//
//            }
//            i++;
//        }
//        i=1;
//
//        while(i<tokens.size()){
//            if(tokens.get(i).getType().equals(Token.TokenTypes.DEDENT)){
//                tokens.add(i+1,new Token(Token.TokenTypes.INDENT,getCurrentLine(),getCurrentColumn()));
//            }
//            i++;
//        }


    }

    public boolean done() {
        return tokens.size() == 0;
    }

    public Optional<Token> matchAndRemove(Token.TokenTypes t) {
        if(t==tokens.getFirst().getType()){
            return Optional.of(tokens.removeFirst());
        }else{
            return Optional.empty();
        }
    }

    public Optional<Token> peek(int i) {
        if(done()){
            return Optional.empty();
        }
        return Optional.ofNullable(tokens.get(i));
    }

    public int getCurrentLine(){
        if(tokens.size()==0){
            return 0;
        }else{
            return tokens.getFirst().getLineNumber();
        }
    }
    public int getCurrentColumn(){
        if(tokens.size()==0){
            return 0;
        }else{
            return tokens.getFirst().getColumnNumber();
        }
    }

    public boolean nextTwoTokensMatch(Token.TokenTypes first, Token.TokenTypes second) {
        if(tokens.size()<2){
            return false;
        }
        return tokens.getFirst().getType().equals(first)&&tokens.get(1).getType().equals(second);
    }
}
