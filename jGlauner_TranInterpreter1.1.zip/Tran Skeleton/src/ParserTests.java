import AST.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


public class ParserTests {
    private TranNode LexAndParse(String input, int tokenCount) throws Exception {
        var l = new Lexer(input);
        var tokens = l.Lex();
        Assertions.assertEquals(tokenCount, tokens.size());
        var tran = new TranNode();
        var p = new Parser(tran, tokens);
        p.Tran();
        return tran;
    }

    @Test
    public void testInterface() throws Exception {
        var t = LexAndParse("interface someName\r\n\tupdateClock()\r\n\tsquare() : number s", 15);
        Assertions.assertEquals(1, t.Interfaces.size());
        Assertions.assertEquals(2, t.Interfaces.getFirst().methods.size());
    }
    @Test
    public void peekMatchColumnLineTest()throws Exception {
        var l = "interface foo\r\n\tbar(number garma, word narnar):number foo,word bar";
        var t = new Lexer(l);
        var tMan = new TokenManager(t.Lex());
        Assertions.assertEquals(tMan.peek(0).get().getColumnNumber(),1);
        Assertions.assertEquals(tMan.peek(0).get().getLineNumber(),1);
        Assertions.assertEquals(tMan.peek(0).get().getType(),Token.TokenTypes.INTERFACE);
        Assertions.assertEquals(tMan.peek(1).get().getType(),Token.TokenTypes.WORD);
        Assertions.assertEquals(tMan.matchAndRemove(Token.TokenTypes.INTERFACE).get().getType(),Token.TokenTypes.INTERFACE);
        Assertions.assertEquals(tMan.matchAndRemove(Token.TokenTypes.INTERFACE).isEmpty(),true);

        var s = LexAndParse(l,18);
        Assertions.assertEquals(1, s.Interfaces.size());
        Assertions.assertEquals(1, s.Interfaces.getFirst().methods.size());
        Assertions.assertEquals(2, s.Interfaces.getFirst().methods.getFirst().returns.size());
        Assertions.assertEquals(2, s.Interfaces.getFirst().methods.getFirst().parameters.size());
    }
    @Test
    public void testClassWithOneMethod() throws Exception {
        var t = LexAndParse("class Tran\r\n\thelloWorld()\r\n\t\tx = 1 + 1", 15);
        Assertions.assertEquals(1, t.Classes.size());
        Assertions.assertEquals(1, t.Classes.getFirst().methods.size());
        Assertions.assertEquals(1, t.Classes.getFirst().methods.getFirst().statements.size());
    }

    @Test
    public void testClassWithMultipleMembers() throws Exception {
        var t = LexAndParse("class Tran\n" +
                "\tnumber w\n" +
                "\tstring x\n" +
                "\tboolean y\n" +
                "\tcharacter z", 18);
        Assertions.assertEquals(1, t.Classes.size());
        Assertions.assertEquals(4, t.Classes.getFirst().members.size());
        var m = t.Classes.getFirst().members;
        Assertions.assertEquals("number", m.getFirst().declaration.type);
        Assertions.assertEquals("w", m.getFirst().declaration.name);
        Assertions.assertEquals("string", m.get(1).declaration.type);
        Assertions.assertEquals("x", m.get(1).declaration.name);
        Assertions.assertEquals("boolean", m.get(2).declaration.type);
        Assertions.assertEquals("y", m.get(2).declaration.name);
        Assertions.assertEquals("character", m.get(3).declaration.type);
        Assertions.assertEquals("z", m.get(3).declaration.name);
    }

    @Test
    public void testClassWithMethodsAndMembers() throws Exception {
        var t = LexAndParse("class Tran\n" +
                        "\tnumber w\n" +
                        "\tstring x\n" +
                        "\tboolean y\n" +
                        "\tcharacter z\n" +
                        "\thelloWorld()\n" +
                        "\t\tx = 1 + 1"
                , 31);
        Assertions.assertEquals(1, t.Classes.size());
        var m = t.Classes.getFirst().members;
        Assertions.assertEquals(4, t.Classes.getFirst().members.size()); // scramble test order to break the "duplicate code" warning
        Assertions.assertEquals("boolean", m.get(2).declaration.type);
        Assertions.assertEquals("y", m.get(2).declaration.name);
        Assertions.assertEquals("character", m.get(3).declaration.type);
        Assertions.assertEquals("z", m.get(3).declaration.name);
        Assertions.assertEquals("string", m.get(1).declaration.type);
        Assertions.assertEquals("x", m.get(1).declaration.name);
        Assertions.assertEquals("number", m.getFirst().declaration.type);
        Assertions.assertEquals("w", m.getFirst().declaration.name);

        Assertions.assertEquals(1, t.Classes.getFirst().methods.size());
        Assertions.assertEquals(1, t.Classes.getFirst().methods.getFirst().statements.size());
    }

    @Test
    public void testClassIf() throws Exception {
        var t = LexAndParse("class Tran\n" +
                        "\thelloWorld()\n" +
                        "\t\tif n>100\n" +
                        "\t\t\tkeepGoing = false"
                , 21);
        Assertions.assertEquals(1, t.Classes.size());
        var myClass = t.Classes.getFirst();
        Assertions.assertEquals(1, myClass.methods.size());
        var myMethod = myClass.methods.getFirst();
        Assertions.assertEquals(1, myMethod.statements.size());
        Assertions.assertEquals("AST.IfNode", myMethod.statements.getFirst().getClass().getName());
        Assertions.assertTrue(((IfNode)(myMethod.statements.getFirst())).elseStatement.isEmpty());
    }

    @Test
    public void testClassIfElse() throws Exception {
        var t = LexAndParse("class Tran\n" +
                        "\thelloWorld()\n" +
                        "\t\tif n>100\n" +
                        "\t\t\tkeepGoing = false\n" +
                        "\t\telse\n" +
                        "\t\t\tkeepGoing = true\n"
                , 33);
        Assertions.assertEquals(1, t.Classes.size());
        var myClass = t.Classes.getFirst();
        Assertions.assertEquals(1, myClass.methods.size());
        var myMethod = myClass.methods.getFirst();
        Assertions.assertEquals(1, myMethod.statements.size());
        Assertions.assertEquals("AST.IfNode", myMethod.statements.getFirst().getClass().getName());
        Assertions.assertTrue(((IfNode)(myMethod.statements.getFirst())).elseStatement.isPresent());
        Assertions.assertEquals(1,((IfNode)(myMethod.statements.getFirst())).elseStatement.orElseThrow().statements.size());
    }

    @Test
    public void testLoopVariable() throws Exception {
        var t = LexAndParse("class Tran\n" +
                        "\thelloWorld()\n" +
                        "\t\tloop n\n" +
                        "\t\t\tkeepGoing = false\n"
                , 20);
        Assertions.assertEquals(1, t.Classes.size());
        var myClass = t.Classes.getFirst();
        Assertions.assertEquals(1, myClass.methods.size());
        var myMethod = myClass.methods.getFirst();
        Assertions.assertEquals(1, myMethod.statements.size());
        Assertions.assertInstanceOf(LoopNode.class, myMethod.statements.getFirst());
    }

    @Test
    public void testLoopCondition() throws Exception {
        var t = LexAndParse("class Tran\n" +
                        "\thelloWorld()\n" +
                        "\t\tloop n<100\n" +
                        "\t\t\tkeepGoing = false\n"
                , 22);
        Assertions.assertEquals(1, t.Classes.size());
        var myClass = t.Classes.getFirst();
        Assertions.assertEquals(1, myClass.methods.size());
        var myMethod = myClass.methods.getFirst();
        Assertions.assertEquals(1, myMethod.statements.size());
        Assertions.assertInstanceOf(LoopNode.class, myMethod.statements.getFirst());
        Assertions.assertInstanceOf(CompareNode.class, ((LoopNode) myMethod.statements.getFirst()).expression);
    }

    @Test
    public void testLoopConditionWithVariable() throws Exception {
        var t = LexAndParse("class Tran\n" +
                        "\thelloWorld()\n" +
                        "\t\tloop c = n<100\n" +
                        "\t\t\tkeepGoing = false\n"
                , 24);
        Assertions.assertEquals(1, t.Classes.size());
        var myClass = t.Classes.getFirst();
        Assertions.assertEquals(1, myClass.methods.size());
        var myMethod = myClass.methods.getFirst();
        Assertions.assertEquals(1, myMethod.statements.size());
        Assertions.assertInstanceOf(LoopNode.class, myMethod.statements.getFirst());
        Assertions.assertTrue(((LoopNode) myMethod.statements.getFirst()).assignment.isPresent());
        Assertions.assertInstanceOf(CompareNode.class, ((LoopNode) myMethod.statements.getFirst()).expression);

    }

    @Test
    public void testMethodCallWithMulitpleVariables() throws Exception {
        var t = LexAndParse("class Tran\n" +
                        "\thelloWorld()\n" +
                        "\t\ta,b,c,d,e = doSomething(number e,object objectus)\n"
                , 29);
        Assertions.assertEquals(1, t.Classes.size());
        var myClass = t.Classes.getFirst();
        Assertions.assertEquals(1, myClass.methods.size());
        var myMethod = myClass.methods.getFirst();
        Assertions.assertEquals(1, myMethod.statements.size());
        var firstStatement = myMethod.statements.getFirst();
        Assertions.assertInstanceOf(MethodCallStatementNode.class, firstStatement);
        Assertions.assertEquals(5,((MethodCallStatementNode) firstStatement).returnValues.size());
    }
    @Test
    public void testConstructor() throws Exception {
        var t = LexAndParse("class Tran\n" +
                        "\tconstruct(number b,word ploorbus)\n\t\tb=5\n\t\tword bubblue"
                , 23);
        Assertions.assertEquals(1, t.Classes.getFirst().constructors.size());
        var myClass = t.Classes.getFirst().constructors.getFirst();
        Assertions.assertEquals(1, myClass.locals.size());
        Assertions.assertEquals(1, myClass.statements.size());
        Assertions.assertEquals(2,myClass.parameters.size());
    }
    @Test
    public void testMethodCallExpression() throws Exception {
        var t = LexAndParse("class Tran\n" +
                "\thelloWorld()\n" +
                "\t\tx = great(googley,moogley)"+
                "\t\tx = new great(googley,moogley)"+
                "\t\tgreat(googley,moogley)", 37);
        var b = t.Classes.getFirst().methods.getFirst().statements;
        Assertions.assertEquals(3, b.size());
        MethodCallStatementNode c = (MethodCallStatementNode) b.get(0);
        Assertions.assertEquals(MethodCallStatementNode.class,c.getClass());
        NewNode m = (NewNode) ((AssignmentNode)b.get(1)).expression;
        Assertions.assertEquals(m.className,"great");
        Assertions.assertEquals(2,m.parameters.size());
        MethodCallStatementNode s = (MethodCallStatementNode) b.get(2);
        Assertions.assertEquals(s.methodName,"great");
        Assertions.assertEquals(2,s.parameters.size());

    }
    @Test
    public void testExpression() throws Exception {
        var t = LexAndParse("class Tran\n" +
                "\thelloWorld()\n" +
                "\t\tx = object(gx*(rand()%size+2))", 26);

        MethodCallStatementNode a = (MethodCallStatementNode) t.Classes.getFirst().methods.getFirst().statements.getFirst();
        MathOpNode m = (MathOpNode)a.parameters.getFirst();
        Assertions.assertEquals("gx",m.left.toString());
        Assertions.assertEquals(MathOpNode.MathOperations.multiply,m.op);
        Assertions.assertEquals(MathOpNode.MathOperations.add,((MathOpNode)m.right).op);
        Assertions.assertEquals(MathOpNode.MathOperations.modulo,((MathOpNode)((MathOpNode)m.right).left).op);
        Assertions.assertEquals(MethodCallExpressionNode.class,((MathOpNode)((MathOpNode)m.right).left).left.getClass());
    }

}
