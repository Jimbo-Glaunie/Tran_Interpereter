
import AST.*;
import Interpreter.Interpreter;
import Interpreter.*;

import java.util.HashMap;
import java.util.LinkedList;
public class Main {
    public static void main(String[] args) throws Exception {
        var l = new Lexer
                (
                "class Student\n" +
                        "\tstring fName\n" +
                        "\tstring lName\n" +
                        "\tnumber mGrade\n" +
                        "\tnumber wGrade\n" +
                        "\tnumber hGrade\n" +
                        "\tconstruct(string f, string l,number m,number w,number h)\n" +
                        "\t\tfName=f\n" +
                        "\t\tlName=l\n" +
                        "\t\tmGrade=m\n" +
                        "\t\twGrade=w\n" +
                        "\t\thGrade=h\n" +
                        "\tgetAverage():number avg\n" +
                        "\t\tavg=(mGrade+wGrade+hGrade)/3\n" +
                        "\tprint()\n" +
                        "\t\tstring student\n" +
                        "\t\tstudent=fName+\" \"+lName+\"\"+getAverage()\n" +
                        "\t\tconsole.write(student)\n" +
                        "\tshared start()\n" +
                        "\t\tStudent hj\n" +
                        "\t\tStudent id\n" +
                        "\t\tStudent cs\n" +
                        "\t\thj=new Student(\"Hugh\",\"Jassle\",93,2,85)\n" +
                        "\t\tid=new Student(\"Ima\",\"Dumas\",43,71,63)\n" +
                        "\t\tcs=new Student(\"Cody\",\"Strudel\",100,89,93)\n" +
                        "\t\thj.print()\n" +
                        "\t\tid.print()\n" +
                        "\t\tcs.print()"
        );



LinkedList <Token> n=l.Lex();
TranNode top = new TranNode();
Parser p = new Parser(top,n);
System.out.println(n);
p.Tran();

//System.out.println(top.Classes.getFirst().constructors);
//System.out.println(top.Classes.getFirst().methods.getLast().statements.getFirst());
var i = new Interpreter(top);
i.start();
System.out.println(((ConsoleWrite)top.Classes.get(1).methods.getFirst()).console);
}

}
