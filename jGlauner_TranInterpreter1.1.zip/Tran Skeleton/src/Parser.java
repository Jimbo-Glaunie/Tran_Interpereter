import AST.*;
import org.w3c.dom.ls.LSOutput;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

public class Parser {
    TranNode top;

    List<Token> tokens;

    TokenManager tokenMan;

    public Parser(TranNode top, List<Token> tokens) {
        this.top = top;
        this.tokenMan= new TokenManager(tokens);
    }
    //handles newlines
    public void requireNewline(){
        while(!tokenMan.done()&&tokenMan.matchAndRemove(Token.TokenTypes.NEWLINE).isPresent()){}
    }
    //Tran = {Interface } | [Class]
    public void Tran() throws SyntaxErrorException {
        boolean classless = true;
        requireNewline();
        while(!tokenMan.done()){
            if (tokenMan.matchAndRemove(Token.TokenTypes.INTERFACE).isPresent()) {
                top.Interfaces.add(Interface());
            } else if (tokenMan.matchAndRemove(Token.TokenTypes.CLASS).isPresent() && classless) {
                top.Classes.add(Class());
                classless = false;
            } else {
                throw new SyntaxErrorException("not a class or interface, or multiple classes", tokenMan.getCurrentLine(), tokenMan.getCurrentColumn());
            }
        }
    }
    //Interface = "interface" Identifier NEWLINE INDENT {MethodHeader NEWLINE } DEDENT
    private InterfaceNode Interface() throws SyntaxErrorException {
        try{
            InterfaceNode interfaceNode=new InterfaceNode();
            interfaceNode.name = tokenMan.matchAndRemove(Token.TokenTypes.WORD).get().getValue();
            requireNewline();
            while(!tokenMan.done()&&!tokenMan.matchAndRemove(Token.TokenTypes.DEDENT).isPresent()){
                tokenMan.matchAndRemove(Token.TokenTypes.INDENT);
                interfaceNode.methods.add(MethodHeader());
                requireNewline();
            }
            return interfaceNode;
        }catch(Exception e){
            throw new SyntaxErrorException("bad interface",tokenMan.getCurrentLine(),tokenMan.getCurrentColumn());
        }
    }
    //MethodHeader = Identifier "(" VariableDeclarations ")" [ ":" VariableDeclaration { ","
    //VariableDeclaration }]
    private MethodHeaderNode MethodHeader() throws SyntaxErrorException {
        try {
            tokenMan.matchAndRemove(Token.TokenTypes.INDENT);
            MethodHeaderNode methodHeaderNode = new MethodHeaderNode();
            methodHeaderNode.name = tokenMan.matchAndRemove(Token.TokenTypes.WORD).get().getValue();
            tokenMan.matchAndRemove(Token.TokenTypes.LPAREN);
            while (!tokenMan.done()&&tokenMan.peek(0).get().getType().equals(Token.TokenTypes.WORD)) {
                methodHeaderNode.parameters.add(VariableDeclaration());
                tokenMan.matchAndRemove(Token.TokenTypes.COMMA);
            }
            tokenMan.matchAndRemove(Token.TokenTypes.RPAREN);

            if (!tokenMan.done()&&tokenMan.matchAndRemove(Token.TokenTypes.COLON).isPresent()) {

                while (!tokenMan.done()&&tokenMan.peek(0).get().getType().equals(Token.TokenTypes.WORD)) {

                    methodHeaderNode.returns.add(VariableDeclaration());

                    if(!tokenMan.done()){
                        tokenMan.matchAndRemove(Token.TokenTypes.COMMA);
                    }
                }

            }
            requireNewline();
            return methodHeaderNode;
        } catch (Exception e) {
            throw new SyntaxErrorException("bad method header",tokenMan.getCurrentLine(),tokenMan.getCurrentColumn());
        }
    }
    //VariableDeclaration = Identifier Identifier
    private VariableDeclarationNode VariableDeclaration() throws SyntaxErrorException {
        VariableDeclarationNode vardecNode =new VariableDeclarationNode();
        vardecNode.type=tokenMan.matchAndRemove(Token.TokenTypes.WORD).get().getValue();
        vardecNode.name=tokenMan.matchAndRemove(Token.TokenTypes.WORD).get().getValue();
        return vardecNode;
    }
    //Class = "class" Identifier [ "implements" Identifier { "," Identifier } ] NEWLINE INDENT {
    //Constructor NEWLINE | MethodDeclaration NEWLINE | Member NEWLINE } DEDENT
    private ClassNode Class() throws SyntaxErrorException {
        try{
            ClassNode classNode=new ClassNode();
            classNode.name=tokenMan.matchAndRemove(Token.TokenTypes.WORD).get().getValue();
            if(tokenMan.matchAndRemove(Token.TokenTypes.IMPLEMENTS).isPresent()){
                classNode.interfaces.add(tokenMan.matchAndRemove(Token.TokenTypes.WORD).get().getValue());
                while(tokenMan.matchAndRemove(Token.TokenTypes.COMMA).isPresent()){
                    classNode.interfaces.add(tokenMan.matchAndRemove(Token.TokenTypes.WORD).get().getValue());
                }
            }
            requireNewline();
            while(!tokenMan.done()&&!tokenMan.matchAndRemove(Token.TokenTypes.DEDENT).isPresent()) {
                tokenMan.matchAndRemove(Token.TokenTypes.INDENT);
                boolean privacy = tokenMan.matchAndRemove(Token.TokenTypes.PRIVATE).isPresent();
                boolean sharing = tokenMan.matchAndRemove(Token.TokenTypes.SHARED).isPresent();
                if(tokenMan.nextTwoTokensMatch(Token.TokenTypes.WORD, Token.TokenTypes.LPAREN)){
                    MethodDeclarationNode declaration=MethodDeclaration();
                    declaration.isPrivate=privacy;
                    declaration.isShared=sharing;
                    classNode.methods.add(declaration);
                }else if(tokenMan.matchAndRemove(Token.TokenTypes.CONSTRUCT).isPresent()){
                    classNode.constructors.add(Construct());
                }else if(!tokenMan.done()){
                    classNode.members.add(Member());
                }
                requireNewline();
            }
            return classNode;
        }catch (Exception e){
            throw new SyntaxErrorException("bad class",tokenMan.getCurrentLine(),tokenMan.getCurrentColumn());
        }
    }
    //Constructor = "construct" "(" VariableDeclarations ")" NEWLINE MethodBody
    private ConstructorNode Construct()throws SyntaxErrorException{
        try{
           ConstructorNode constructorNode=new ConstructorNode();
            tokenMan.matchAndRemove(Token.TokenTypes.LPAREN);
            while (!tokenMan.done()&&tokenMan.peek(0).get().getType().equals(Token.TokenTypes.WORD)) {
                constructorNode.parameters.add(VariableDeclaration());
                tokenMan.matchAndRemove(Token.TokenTypes.COMMA);
            }
            tokenMan.matchAndRemove(Token.TokenTypes.RPAREN);
            requireNewline();
            while(!tokenMan.done()&&!tokenMan.matchAndRemove(Token.TokenTypes.DEDENT).isPresent()) {
                tokenMan.matchAndRemove(Token.TokenTypes.INDENT);
                if(tokenMan.nextTwoTokensMatch(Token.TokenTypes.WORD, Token.TokenTypes.WORD)){
                    constructorNode.locals.add(VariableDeclaration());
                }else{
                    constructorNode.statements.add(Statement());
                }
                requireNewline();
            }
            requireNewline();
           return constructorNode;
        } catch (Exception e) {
            throw new SyntaxErrorException("bad construct",tokenMan.getCurrentLine(),tokenMan.getCurrentColumn());
        }
    }
    //Member = VariableDeclaration ["accessor:" Statements] ["mutator:" Statements]
    private MemberNode Member() throws SyntaxErrorException {
        try{
            MemberNode member = new MemberNode();
            do {
                member.declaration = VariableDeclaration();
                if(!tokenMan.done()&&tokenMan.matchAndRemove(Token.TokenTypes.ACCESSOR).isPresent()){
                    tokenMan.matchAndRemove(Token.TokenTypes.COLON);
                    List<StatementNode> accessor = new ArrayList<StatementNode>();
                    accessor.add(Statement());
                    requireNewline();
                    while(!tokenMan.done()&&!tokenMan.matchAndRemove(Token.TokenTypes.DEDENT).isPresent()) {
                        tokenMan.matchAndRemove(Token.TokenTypes.INDENT);
                        accessor.add(Statement());
                        requireNewline();
                        break;
                    }
                    member.accessor=Optional.of(accessor);
                }

                if(!tokenMan.done()&&tokenMan.matchAndRemove(Token.TokenTypes.MUTATOR).isPresent()){
                    tokenMan.matchAndRemove(Token.TokenTypes.COLON);
                    List<StatementNode> mutator = new ArrayList<StatementNode>();
                    mutator.add(Statement());
                    requireNewline();
                    while(!tokenMan.done()&&!tokenMan.matchAndRemove(Token.TokenTypes.DEDENT).isPresent()) {
                        tokenMan.matchAndRemove(Token.TokenTypes.INDENT);
                        mutator.add(Statement());
                        requireNewline();
                        break;
                    }
                    member.mutator=Optional.of(mutator);
                }
            }while(!tokenMan.done()&&tokenMan.matchAndRemove(Token.TokenTypes.COMMA).isPresent());
            return member;
        }catch(Exception e){
            throw new SyntaxErrorException("bad member",tokenMan.getCurrentLine(),tokenMan.getCurrentColumn());
        }
    }
    //MethodDeclaration = ["private"] ["shared"] MethodHeader NEWLINE MethodBody
    //MethodBody = INDENT { VariableDeclaration NEWLINE } {Statement} DEDENT
    private MethodDeclarationNode MethodDeclaration() throws SyntaxErrorException {
        try{
            tokenMan.matchAndRemove(Token.TokenTypes.INDENT);
            MethodDeclarationNode nodey=new MethodDeclarationNode();
            MethodHeaderNode header = MethodHeader();
            nodey.name=header.name;
            nodey.returns=header.returns;
            nodey.parameters=header.parameters;
            requireNewline();
            while(!tokenMan.done()&&!tokenMan.matchAndRemove(Token.TokenTypes.DEDENT).isPresent()){
                tokenMan.matchAndRemove(Token.TokenTypes.INDENT);
                if(tokenMan.nextTwoTokensMatch(Token.TokenTypes.WORD, Token.TokenTypes.WORD)){
                    nodey.locals.add(VariableDeclaration());
                }else{
                    nodey.statements.add(Statement());
                }
                requireNewline();
            }
            requireNewline();
            return nodey;
        }catch(Exception e){
            throw new SyntaxErrorException("bad method declaration",tokenMan.getCurrentLine(),tokenMan.getCurrentColumn());
        }
    }



    private StatementNode Statement() throws SyntaxErrorException {
        try {
            if (tokenMan.matchAndRemove(Token.TokenTypes.IF).isPresent()) {
                return If();
            }else if(tokenMan.matchAndRemove(Token.TokenTypes.LOOP).isPresent()||(tokenMan.tokens.size()>2&&tokenMan.peek(2).get().getType().equals(Token.TokenTypes.LOOP))){
                return Loop();
            }else{
                return Disambiguate().get();
            }
        }catch(Exception e){
            throw new SyntaxErrorException("bad statement",tokenMan.getCurrentLine(),tokenMan.getCurrentColumn());
        }
    }
    //If = "if" BoolExp NEWLINE Statements ["else" NEWLINE (Statement | Statements)]
    private IfNode If() throws SyntaxErrorException {
        try{

            IfNode ifNode=new IfNode();
            ifNode.statements=new ArrayList<>();
            ifNode.condition=BooleanTerm();
            requireNewline();

            while(!tokenMan.done()&&!tokenMan.matchAndRemove(Token.TokenTypes.DEDENT).isPresent()){
                tokenMan.matchAndRemove(Token.TokenTypes.INDENT);
                ifNode.statements.add(Statement());
                requireNewline();
            }
            if(!tokenMan.done()){
                tokenMan.matchAndRemove(Token.TokenTypes.INDENT);
            }
            if(!tokenMan.done()&&tokenMan.matchAndRemove(Token.TokenTypes.ELSE).isPresent()){
                requireNewline();
                ElseNode elsey=new ElseNode();
                elsey.statements=new ArrayList<>();
                while(!tokenMan.done()&&!tokenMan.matchAndRemove(Token.TokenTypes.DEDENT).isPresent()){
                    tokenMan.matchAndRemove(Token.TokenTypes.INDENT);
                    elsey.statements.add(Statement());
                    requireNewline();
                }
                ifNode.elseStatement=Optional.of(elsey);
            }
            requireNewline();
            return ifNode;
        }catch(Exception e){
            throw new SyntaxErrorException("bad if/else",tokenMan.getCurrentLine(),tokenMan.getCurrentColumn());
        }
    }
    //Loop = [VariableReference "=" ] "loop" ( BoolExpTerm ) NEWLINE Statements
    private LoopNode Loop()throws SyntaxErrorException{
        LoopNode loopNode=new LoopNode();
        if(!tokenMan.done()&&tokenMan.peek(1).get().getType().equals(Token.TokenTypes.ASSIGN)){
            VariableReferenceNode variableReferenceNode=VariableReference();
            tokenMan.matchAndRemove(Token.TokenTypes.ASSIGN);
            loopNode.assignment=Optional.of(variableReferenceNode);
            tokenMan.matchAndRemove(Token.TokenTypes.LOOP);
        }
        loopNode.expression=BooleanTerm();
        requireNewline();
        while(!tokenMan.done()&&!tokenMan.matchAndRemove(Token.TokenTypes.DEDENT).isPresent()){
            tokenMan.matchAndRemove(Token.TokenTypes.INDENT);
            StatementNode nodey=Statement();
            loopNode.statements.add(nodey);
            requireNewline();
        }
        return loopNode;
    }
    //BoolExpTerm = BoolExpFactor {("and"|"or") BoolExpTerm} | "not" BoolExpTerm
    private ExpressionNode BooleanTerm() throws SyntaxErrorException {
        BooleanOpNode termNode=new BooleanOpNode();
        if(tokenMan.matchAndRemove(Token.TokenTypes.NOT).isPresent()){
            NotOpNode notOpNode=new NotOpNode();
            notOpNode.left=BooleanTerm();
            termNode.left=notOpNode;
        }else{
            termNode.left=BooleanFactor();
            if(!tokenMan.done()&&tokenMan.matchAndRemove(Token.TokenTypes.AND).isPresent()){
                termNode.op= BooleanOpNode.BooleanOperations.and;
                termNode.right=BooleanTerm();
            }else if(!tokenMan.done()&&tokenMan.matchAndRemove(Token.TokenTypes.OR).isPresent()){
                termNode.op= BooleanOpNode.BooleanOperations.or;
                termNode.right=BooleanTerm();
            }else{
                return termNode.left;
            }
        }
        return termNode;
    }
    //BoolExpFactor = MethodCallExpression | (Expression ( "==" | "!=" | "<=" | ">=" | ">" | "<" )
    //Expression) | VariableReference
    private ExpressionNode BooleanFactor() throws SyntaxErrorException {
        ExpressionNode factorNode=null;
        if(tokenMan.peek(1).get().getType().equals(Token.TokenTypes.LPAREN)||tokenMan.peek(1).get().getType().equals(Token.TokenTypes.DOT)){
            factorNode=MethodCallExpression().get();
        }else if(tokenMan.peek(1).get().getType().equals(Token.TokenTypes.NEWLINE)||tokenMan.peek(1).get().getType().equals(Token.TokenTypes.OR)||tokenMan.peek(1).get().getType().equals(Token.TokenTypes.AND)){
            factorNode=VariableOrLiteral();
        }else{
            CompareNode compareNode=new CompareNode();

            compareNode.left=Expression();
            switch(tokenMan.peek(0).get().getType()){
                case Token.TokenTypes.EQUAL:
                    tokenMan.matchAndRemove(Token.TokenTypes.EQUAL);
                    compareNode.op= CompareNode.CompareOperations.eq;
                    break;
                case Token.TokenTypes.NOTEQUAL:
                    tokenMan.matchAndRemove(Token.TokenTypes.NOTEQUAL);
                    compareNode.op= CompareNode.CompareOperations.ne;
                    break;
                case Token.TokenTypes.GREATERTHAN:
                    tokenMan.matchAndRemove(Token.TokenTypes.GREATERTHAN);
                    compareNode.op= CompareNode.CompareOperations.gt;
                    break;
                case Token.TokenTypes.LESSTHAN:
                    tokenMan.matchAndRemove(Token.TokenTypes.LESSTHAN);
                    compareNode.op= CompareNode.CompareOperations.lt;
                    break;
                case Token.TokenTypes.GREATERTHANEQUAL:
                    tokenMan.matchAndRemove(Token.TokenTypes.GREATERTHANEQUAL);
                    compareNode.op= CompareNode.CompareOperations.ge;
                    break;
                case Token.TokenTypes.LESSTHANEQUAL:
                    tokenMan.matchAndRemove(Token.TokenTypes.LESSTHANEQUAL);
                    compareNode.op= CompareNode.CompareOperations.le;
                    break;
            }

            compareNode.right=Expression();

            factorNode=compareNode;
        }
        return factorNode;
    }


    private Optional<StatementNode> Disambiguate() throws SyntaxErrorException {
        Optional<MethodCallExpressionNode> methodCallExpression = MethodCallExpression();
        if(methodCallExpression.isPresent()){
            return Optional.of(new MethodCallStatementNode(methodCallExpression.get()));
        }
        if(tokenMan.peek(1).get().getType().equals(Token.TokenTypes.ASSIGN)){
           if((tokenMan.tokens.size()>3&&tokenMan.peek(3).get().getType().equals(Token.TokenTypes.LPAREN))){
                return Optional.of(MethodCall());
           }
            return Optional.of(Assignment());
        }else if(tokenMan.peek(1).get().getType().equals(Token.TokenTypes.COMMA)){
            return Optional.of(MethodCall());
        }
        return Optional.empty();
    }

    private StatementNode Assignment() throws SyntaxErrorException {
        AssignmentNode assignmentNode=new AssignmentNode();
        assignmentNode.target=VariableReference();
        tokenMan.matchAndRemove(Token.TokenTypes.ASSIGN);

        int i=0;
        Token t=tokenMan.peek(i).get();
        boolean bool=false;
        while(!tokenMan.done()&&!t.getType().equals(Token.TokenTypes.NEWLINE)){
            if(t.getType().equals(Token.TokenTypes.EQUAL)||t.getType().equals(Token.TokenTypes.GREATERTHANEQUAL)||t.getType().equals(Token.TokenTypes.GREATERTHAN)||t.getType().equals(Token.TokenTypes.LESSTHANEQUAL)||t.getType().equals(Token.TokenTypes.LESSTHAN)||t.getType().equals(Token.TokenTypes.NOTEQUAL)){
                bool=true;
                break;
            }
            i++;
            t=tokenMan.peek(i).get();
        }
        if(bool){
            assignmentNode.expression=BooleanTerm();
        }else{
            assignmentNode.expression=Expression();
        }
        return assignmentNode;
    }
    //MethodCall = [VariableReference { "," VariableReference } "=" MethodCallExpression
    private MethodCallStatementNode MethodCall() throws SyntaxErrorException {
        List<VariableReferenceNode> returnList = new ArrayList<>();
        do{
           returnList.add(VariableReference());
        }while(!tokenMan.done()&&tokenMan.matchAndRemove(Token.TokenTypes.COMMA).isPresent());
        tokenMan.matchAndRemove(Token.TokenTypes.ASSIGN);
        MethodCallStatementNode mcsNode = new MethodCallStatementNode(MethodCallExpression().get());
        mcsNode.returnValues=returnList;
        return mcsNode;
    }
    //MethodCallExpression = [Identifier "."] Identifier "(" [Expression {"," Expression }] ")"
    private Optional<MethodCallExpressionNode> MethodCallExpression() throws SyntaxErrorException {
        MethodCallExpressionNode mceNode=new MethodCallExpressionNode();
        if(tokenMan.peek(1).get().getType().equals(Token.TokenTypes.DOT)){
            mceNode.objectName=Optional.of(tokenMan.matchAndRemove(Token.TokenTypes.WORD).get().getValue());
            tokenMan.matchAndRemove(Token.TokenTypes.DOT);
        }else{
            mceNode.objectName=Optional.empty();
        }
        if(tokenMan.peek(1).get().getType().equals(Token.TokenTypes.LPAREN)){
            mceNode.methodName=tokenMan.matchAndRemove(Token.TokenTypes.WORD).get().getValue();
            tokenMan.matchAndRemove(Token.TokenTypes.LPAREN);
            while(!tokenMan.done()&&!tokenMan.matchAndRemove(Token.TokenTypes.RPAREN).isPresent()){
                mceNode.parameters.add(Expression());
                tokenMan.matchAndRemove(Token.TokenTypes.COMMA);
            }
        }else{
            return Optional.empty();
        }
        return Optional.of(mceNode);
    }
    //Expression = Term { ("+"|"-") Term }
    private ExpressionNode Expression() throws SyntaxErrorException {
        ExpressionNode L = Term();
        Token.TokenTypes token;
        if(!tokenMan.done()){
            token =tokenMan.peek(0).get().getType();
        }else{
            token =null;
        }
        while(!tokenMan.done()&&(token.equals(Token.TokenTypes.PLUS)||token.equals(Token.TokenTypes.MINUS))){
            if(tokenMan.matchAndRemove(Token.TokenTypes.PLUS).isPresent()){
                ExpressionNode R =Term();
                MathOpNode mathOp = new MathOpNode();
                mathOp.op= MathOpNode.MathOperations.add;
                mathOp.right=R;
                mathOp.left=L;
                L=mathOp;
            }else if(tokenMan.matchAndRemove(Token.TokenTypes.MINUS).isPresent()){
                ExpressionNode R =Term();
                MathOpNode mathOp = new MathOpNode();
                mathOp.op= MathOpNode.MathOperations.subtract;
                mathOp.right=R;
                mathOp.left=L;
                L=mathOp;
            }
            if(!tokenMan.done()){
                token =tokenMan.peek(0).get().getType();
            }
        }
        return L;
    }
    //Term = Factor { ("*"|"/"|"%") Factor }
    private ExpressionNode Term() throws SyntaxErrorException {
        ExpressionNode L = Factor();
        Token.TokenTypes token;
        if(!tokenMan.done()){
            token =tokenMan.peek(0).get().getType();
        }else{
            token =Token.TokenTypes.COMMA;
        }
        while(!tokenMan.done()&&token.equals(Token.TokenTypes.TIMES)||token.equals(Token.TokenTypes.DIVIDE)||token.equals(Token.TokenTypes.MODULO)){
            if(tokenMan.matchAndRemove(Token.TokenTypes.DIVIDE).isPresent()){
                ExpressionNode R =Factor();
                MathOpNode mathOp = new MathOpNode();
                mathOp.op= MathOpNode.MathOperations.divide;
                mathOp.right=R;
                mathOp.left=L;
                L=mathOp;
            }else if(tokenMan.matchAndRemove(Token.TokenTypes.TIMES).isPresent()){
                ExpressionNode R =Factor();
                MathOpNode mathOp = new MathOpNode();
                mathOp.op= MathOpNode.MathOperations.multiply;
                mathOp.right=R;
                mathOp.left=L;
                L=mathOp;
            }else if(tokenMan.matchAndRemove(Token.TokenTypes.MODULO).isPresent()){
                ExpressionNode R =Factor();
                MathOpNode mathOp = new MathOpNode();
                mathOp.op= MathOpNode.MathOperations.modulo;
                mathOp.right=R;
                mathOp.left=L;
                L=mathOp;
            }
            if(!tokenMan.done()){
                token =tokenMan.peek(0).get().getType();
            }
        }
        return L;
    }
    //Factor = NumberLiteral | VariableReference | "true" | "false" | StringLiteral | CharacterLiteral
    //| MethodCallExpression | "(" Expression ")" |
    // "new" Identifier "(" [Expression {"," Expression }]")"
    private ExpressionNode Factor() throws SyntaxErrorException {
        if(tokenMan.matchAndRemove(Token.TokenTypes.LPAREN).isPresent()){
            ExpressionNode nodey = Expression();
            tokenMan.matchAndRemove(Token.TokenTypes.RPAREN);
            return nodey;
        }else if(tokenMan.matchAndRemove(Token.TokenTypes.NEW).isPresent()){
            NewNode newNode = new NewNode();
            MethodCallExpressionNode holder = MethodCallExpression().get();
            newNode.parameters=holder.parameters;
            newNode.className=holder.methodName;
            return newNode;
        }else if(tokenMan.nextTwoTokensMatch(Token.TokenTypes.WORD, Token.TokenTypes.LPAREN)){
            return MethodCallExpression().get();
        }
        return VariableOrLiteral();

    }

    //returns a node with a variable or a literal
    private ExpressionNode VariableOrLiteral() throws SyntaxErrorException {
        if (tokenMan.peek(0).get().getType().equals(Token.TokenTypes.NUMBER)) {
            NumericLiteralNode numNode = new NumericLiteralNode();
            numNode.value = Float.parseFloat(tokenMan.matchAndRemove(Token.TokenTypes.NUMBER).get().getValue());
            return numNode;
        } else if (tokenMan.peek(0).get().getType().equals(Token.TokenTypes.QUOTEDCHARACTER)) {
            CharLiteralNode charNode = new CharLiteralNode();
            charNode.value = tokenMan.matchAndRemove(Token.TokenTypes.QUOTEDCHARACTER).get().getValue().charAt(0);
            return charNode;
        } else if (tokenMan.peek(0).get().getType().equals(Token.TokenTypes.QUOTEDSTRING)) {
            StringLiteralNode strNode = new StringLiteralNode();
            strNode.value = tokenMan.matchAndRemove(Token.TokenTypes.QUOTEDSTRING).get().getValue();
            return strNode;
        } else if(tokenMan.matchAndRemove(Token.TokenTypes.TRUE).isPresent()){
            BooleanLiteralNode boolNode= new BooleanLiteralNode(true);
            return boolNode;
        }else if(tokenMan.matchAndRemove(Token.TokenTypes.FALSE).isPresent()){
            BooleanLiteralNode boolNode= new BooleanLiteralNode(false);
            return boolNode;
        }else{
            return VariableReference();
        }
    }
    //this is a word that is a reference to a declared variable, simple as
    private VariableReferenceNode VariableReference() throws SyntaxErrorException {
        VariableReferenceNode variableReferenceNode=new VariableReferenceNode();
        variableReferenceNode.name=tokenMan.matchAndRemove(Token.TokenTypes.WORD).get().getValue();
        return variableReferenceNode;
    }
}