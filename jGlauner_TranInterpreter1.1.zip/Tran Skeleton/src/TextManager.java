public class TextManager {

    private int position = 0;

    private String input;

    public TextManager(String input) {
        this.input=input+" ";
    }

    public boolean isAtEnd() {
        return position >= input.length();
    }

    public char peekCharacter() {
        return input.charAt(position);
    }

    public char peekCharacter(int distance) {
        return input.charAt(position+distance);
    }

    public char getCharacter() {
        return input.charAt(position++);
    }

    public int getPosition() {
        return position;
    }
}
