package Interpreter;

import AST.*;
import com.sun.jdi.Value;

import java.util.*;

public class Interpreter {
    final private TranNode top;
    /** Constructor - get the interpreter ready to run. Set members from parameters and "prepare" the class.
     *
     * Store the tran node.
     * Add any built-in methods to the AST
     * @param top - the head of the AST
     */
    public Interpreter(TranNode top) {
        this.top=top;

        ClassNode consoleNode=new ClassNode();
        consoleNode.name="console";
        ConsoleWrite writeNode=new ConsoleWrite();
        writeNode.isShared=true;
        writeNode.name="write";
        writeNode.isVariadic=true;
        consoleNode.methods.add(writeNode);
        top.Classes.add(consoleNode);



    }

    /**
     * This is the public interface to the interpreter. After parsing, we will create an interpreter and call start to
     * start interpreting the code.
     *
     * Search the classes in Tran for a method that is "isShared", named "start", that is not private and has no parameters
     * Call "InterpretMethodCall" on that method, then return.
     * Throw an exception if no such method exists.
     */
    public void start() throws Exception {
        boolean start=false;
        ObjectIDT thisClass = new ObjectIDT(top.Classes.getFirst());
        for(MemberNode member:top.Classes.getFirst().members){
            var global = member.declaration;
            thisClass.members.put(global.name,instantiate(global.type));
        }
        ObjectIDT consoleObj=new ObjectIDT(top.Classes.get(1));
        for(MethodDeclarationNode nodey: top.Classes.getFirst().methods){
            if(nodey.name.equals("start")) {
                if (!nodey.isShared) {
                    throw new Exception("start method not shared");
                } else if(start){throw new Exception("multiple start methods");}else{
                    start = true;
                    List<InterpreterDataType> value = new ArrayList<>();
                    value.add(consoleObj);
                    interpretMethodCall(Optional.of(thisClass),nodey,value);
                }
            }
        }
        if(!start){
            throw new Exception("no start method");
        }

    }

    //              Running Methods

    /**
     * Find the method (local to this class, shared (like Java's $ystem.out.print), or a method on another class)
     * Evaluate the parameters to have a list of values
     * Use interpretMethodCall() to actually run the method.
     *
     * Call GetParameters() to get the parameter value list
     * Find the method. This is tricky - there are several cases:
     * someLocalMethod() - has NO object name. Look in "object"
     * Interpreter.console.write() - the objectName is a CLASS and the method is shared
     * bestStudent.getGPA() - the objectName is a local or a member
     *
     * Once you find the method, call InterpretMethodCall() on it. Return the list that it returns.
     * Throw an exception if we can't find a match.
     * @param object - the object we are inside right now (might be empty)
     * @param locals - the current local variables
     * @param mc - the method call
     * @return - the return values
     */
    private List<InterpreterDataType> findMethodForMethodCallAndRunIt(Optional<ObjectIDT> object, HashMap<String, InterpreterDataType> locals, MethodCallStatementNode mc) throws Exception {
        List<InterpreterDataType> result;
        MethodDeclarationNode rightMethod = null;
        for(ClassNode classy:top.Classes){
            for(MethodDeclarationNode method:classy.methods){
                if(mc.methodName.equals(method.name)){
                    rightMethod=method;
                }
            }
        }
        if(rightMethod==null){
            throw new Exception(mc.methodName+" does not exist");
        }
        Optional<ObjectIDT> rightObject=object;
        if(mc.objectName.isPresent()){
            rightObject=((ReferenceIDT)findVariable(mc.objectName.get(),locals,object)).refersTo;
        }
        List<InterpreterDataType> rightValues=new ArrayList<>();
        for(ExpressionNode param:mc.parameters){
            rightValues.add(evaluate(locals,object,param));
        }
        if(rightMethod.getClass()==ConsoleWrite.class){
            ((ConsoleWrite)top.Classes.get(1).methods.getFirst()).Execute(rightValues);
        }

        result=interpretMethodCall(rightObject,rightMethod,rightValues);
        return result;
    }

    /**
     * Run a "prepared" method (found, parameters evaluated)
     * This is split from findMethodForMethodCallAndRunIt() because there are a few cases where we don't need to do the finding:
     * in start() and dealing with loops with iterator objects, for example.
     *
     * Check to see if "m" is a built-in. If so, call Execute() on it and return
     * Make local variables, per "m"
     * If the number of passed in values doesn't match m's "expectations", throw
     * Add the parameters by name to locals.
     * Call InterpretStatementBlock
     * Build the return list - find the names from "m", then get the values for those names and add them to the list.
     * @param object - The object this method is being called on (might be empty for shared)
     * @param m - Which method is being called
     * @param values - The values to be passed in
     * @return the returned values from the method
     */
    private List<InterpreterDataType> interpretMethodCall(Optional<ObjectIDT> object, MethodDeclarationNode m, List<InterpreterDataType> values) throws Exception{

        var retVal = new LinkedList<InterpreterDataType>();
        for(VariableDeclarationNode rs:m.returns){
            object.get().members.put(rs.name,instantiate(rs.type));
        }
        for(VariableDeclarationNode local:m.locals){
            object.get().members.put(local.name,instantiate(local.type));
        }
        var ref = new ReferenceIDT();
        ref.refersTo=Optional.of(new ObjectIDT(top.Classes.get(1)));
        object.get().members.put("console",ref);

        if(!values.isEmpty()){
            for(int i=0;i<m.parameters.size();i++){
                object.get().members.put(m.parameters.get(i).name,values.get(i));
            }
        }
        interpretStatementBlock(object,m.statements,object.get().members);
        if(!m.returns.isEmpty()){
            for(VariableDeclarationNode ret:m.returns){
                retVal.add(object.get().members.get(ret.name));
            }
        }

        return retVal;
    }

    //              Running Constructors

    /**
     * This is a special case of the code for methods. Just different enough to make it worthwhile to split it out.
     *
     * Call GetParameters() to populate a list of IDT's
     * Call GetClassByName() to find the class for the constructor
     * If we didn't find the class, throw an exception
     * Find a constructor that is a good match - use DoesConstructorMatch()
     * Call InterpretConstructorCall() on the good match
     * @param object - the object that we are inside when we called the constructor
     * @param locals - the current local variables (used to fill parameters)
     * @param newcall  - the method call for this construction
     */
    private ReferenceIDT findConstructorAndRunIt(Optional<ObjectIDT> object, HashMap<String, InterpreterDataType> locals, NewNode newcall) throws Exception {
        ConstructorNode rightConstructor=null;
        List<InterpreterDataType> newValues=new ArrayList<>();
        List<InterpreterDataType> conValues=new ArrayList<>();
        ClassNode rightClass=null;
        for(ClassNode classy:top.Classes){
            if(classy.name.equals(newcall.className)){
                rightClass=classy;
                for(ConstructorNode con: classy.constructors){
                    if(con.parameters.size()==newcall.parameters.size()){
                        for(ExpressionNode exp: newcall.parameters){
                            newValues.add(evaluate(locals,object,exp));
                        }
                        for(VariableDeclarationNode exp: con.parameters){
                            conValues.add(instantiate(exp.type));
                        }

                        rightConstructor=con;

                    }
                }
            }
        }
        if(rightConstructor==null){
            throw new Exception("constructor of object "+newcall.className+" of size "+newcall.parameters.size()+" does not exist");
        }
        ReferenceIDT newObject= new ReferenceIDT();
        newObject.refersTo= Optional.of(interpretConstructorCall(rightConstructor, newValues,rightClass));


        return newObject;
    }

    /**
     * Similar to interpretMethodCall, but "just different enough" - for example, constructors don't return anything.
     *
     * Creates local variables (as defined by the ConstructorNode), calls Instantiate() to do the creation
     * Checks to ensure that the right number of parameters were passed in, if not throw.
     * Adds the parameters (with the names from the ConstructorNode) to the locals.
     * Calls InterpretStatementBlock
     * @param c - which constructor is being called
     * @param values - the parameter values being passed to the constructor
     * @param  classy - the class of c
     */
    private ObjectIDT interpretConstructorCall(ConstructorNode c, List<InterpreterDataType> values,ClassNode classy) throws Exception {
        ObjectIDT newObject = new ObjectIDT(classy);
        for(VariableDeclarationNode local:c.parameters){
            newObject.members.put(local.name,instantiate(local.type));
        }
        for(int i=0;i<values.size();i++){
            newObject.members.get(c.parameters.get(i).name).Assign(values.get(i));
        }
        for(MemberNode member: classy.members){
            newObject.members.put(member.declaration.name,instantiate(member.declaration.type));
        }
        interpretStatementBlock(Optional.of(newObject),c.statements,newObject.members);
        return newObject;
    }

    //              Running Instructions

    /**
     * Given a block (which could be from a method or an "if" or "loop" block, run each statement.
     * Blocks, by definition, do ever statement, so iterating over the statements makes sense.
     *
     * For each statement in statements:
     * check the type:
     *      For AssignmentNode, FindVariable() to get the target. Evaluate() the expression. Call Assign() on the target with the result of Evaluate()
     *      For MethodCallStatementNode, call doMethodCall(). Loop over the returned values and copy the into our local variables
     *      For LoopNode - there are 2 kinds.
     *          Setup:
     *          If this is a Loop over an iterator (an Object node whose class has "iterator" as an interface)
     *              Find the "getNext()" method; throw an exception if there isn't one
     *          Loop:
     *          While we are not done:
     *              if this is a boolean loop, Evaluate() to get true or false.
     *              if this is an iterator, call "getNext()" - it has 2 return values. The first is a boolean (was there another?), the second is a value
     *              If the loop has an assignment variable, populate it: for boolean loops, the true/false. For iterators, the "second value"
     *              If our answer from above is "true", InterpretStatementBlock() on the body of the loop.
     *       For If - Evaluate() the condition. If true, InterpretStatementBlock() on the if's statements. If not AND there is an else, InterpretStatementBlock on the else body.
     * @param object - the object that this statement block belongs to (used to get member variables and any members without an object)
     * @param statements - the statements to run
     * @param locals - the local variables
     */
    private void interpretStatementBlock(Optional<ObjectIDT> object, List<StatementNode> statements, HashMap<String, InterpreterDataType> locals) throws Exception {
        for(StatementNode statement:statements){
            if(statement.getClass().equals(AssignmentNode.class)){
                InterpreterDataType variable=findVariable(((AssignmentNode) statement).target.name,locals,object);
                if(variable!=null) {
                    variable.Assign(evaluate(locals,object,((AssignmentNode) statement).expression));
                }else{
                    throw new Exception("Variable named "+((AssignmentNode) statement).target.name+"does not exist");
                }
            }else if(statement.getClass().equals(IfNode.class)){
                if(((BooleanIDT) Objects.requireNonNull(evaluate(locals, object, ((IfNode) statement).condition))).Value){
                    interpretStatementBlock(object,((IfNode) statement).statements,locals);
                }else{
                    interpretStatementBlock(object,((IfNode) statement).elseStatement.get().statements,locals);
                }
            }else if(statement.getClass().equals(LoopNode.class)){
                float n=0;
                float max=0;
                boolean forLoop=false;
                if(((LoopNode) statement).assignment.isPresent()){
                    locals.get(((LoopNode) statement).assignment.get().name);
                    if(findVariable(((LoopNode) statement).assignment.get().name,locals,object).getClass()==NumberIDT.class){
                        findVariable(((LoopNode) statement).assignment.get().name,locals,object).Assign(new NumberIDT(n));
                    }else{
                        throw new Exception("Variable not found or not a number");
                    }
                }
                if(((LoopNode) statement).expression.getClass()==MethodCallExpressionNode.class){
                    if(((MethodCallExpressionNode)((LoopNode) statement).expression).methodName.equals("times")){
                        forLoop=true;
                        max=((NumberIDT)findVariable(((MethodCallExpressionNode)((LoopNode) statement).expression).objectName.get(),locals,object)).Value;
                    }
                }
                if(forLoop){
                    for(float N=n;N<max;n+=1.0){
                        interpretStatementBlock(object, ((LoopNode) statement).statements, locals);
                        if(((LoopNode) statement).assignment.isPresent()){
                            findVariable(((LoopNode) statement).assignment.get().name,locals,object).Assign(new NumberIDT(N));
                        }
                    }
                }else{
                    while(((BooleanIDT)evaluate(locals,object,((LoopNode) statement).expression)).Value){
                        interpretStatementBlock(object, ((LoopNode) statement).statements, locals);
                    }
                    if(((LoopNode) statement).assignment.isPresent()){
                        findVariable(((LoopNode) statement).assignment.get().name,locals,object).Assign(new NumberIDT(n+1.0F));
                    }
                }
            }else if (statement.getClass().equals(MethodCallStatementNode.class)){
                List<InterpreterDataType> result=findMethodForMethodCallAndRunIt(object,locals, (MethodCallStatementNode) statement);
                for(int i=0;i<((MethodCallStatementNode) statement).returnValues.size();i++){
                    findVariable(((MethodCallStatementNode) statement).returnValues.get(i).name,locals,object).Assign(result.get(i));
                }


            }
        }
    }

    private boolean findString(ExpressionNode math,HashMap<String,InterpreterDataType> locals,Optional<ObjectIDT> object) throws Exception {
        boolean str=false;
        if(math.getClass().equals(VariableReferenceNode.class)&&Objects.requireNonNull(evaluate(locals, object, math)).getClass()==StringIDT.class){
            str= true;
        }else if(math.getClass()==StringLiteralNode.class){
            str= true;
        }else if(math.getClass().equals(MathOpNode.class)&&((MathOpNode)math).op== MathOpNode.MathOperations.add){
            str= findString(((MathOpNode)math).left,locals,object)||findString(((MathOpNode)math).right,locals,object);
        }
        return str;

    }

    /**
     *  evaluate() processes everything that is an expression - math, variables, boolean expressions.
     *  There is a good bit of recursion in here, since math and comparisons have left and right sides that need to be evaluated.
     *
     * See the How To Write an Interpreter document for examples
     * For each possible ExpressionNode, do the work to resolve it:
     * BooleanLiteralNode - create a new BooleanLiteralNode with the same value
     *      - Same for all of the basic data types
     * BooleanOpNode - Evaluate() left and right, then perform either and/or on the results.
     * CompareNode - Evaluate() both sides. Do good comparison for each data type
     * MathOpNode - Evaluate() both sides. If they are both numbers, do the math using the built-in operators. Also handle String + String as concatenation (like Java)
     * MethodCallExpression - call doMethodCall() and return the first value
     * VariableReferenceNode - call findVariable()
     * @param locals the local variables
     * @param object - the current object we are running
     * @param expression - some expression to evaluate
     * @return a value
     */
    private InterpreterDataType evaluate(HashMap<String, InterpreterDataType> locals, Optional<ObjectIDT> object, ExpressionNode expression) throws Exception {
        InterpreterDataType result = null;
        if(expression.getClass() == MathOpNode.class&&findString(expression,locals,object)&&((MathOpNode)expression).op== MathOpNode.MathOperations.add){
            MathOpNode mathOp = (MathOpNode) expression;
            String str="";
            var l=Objects.requireNonNull(evaluate(locals, object, mathOp.left));
            var r =Objects.requireNonNull(evaluate(locals, object, mathOp.right));
            String ls="";
            String rs="";
            if(l.getClass()==StringIDT.class){
                ls=((StringIDT)l).Value;
            }else if(l.getClass()==NumberIDT.class){
                ls=""+((NumberIDT)l).Value;
            }else if(l.getClass()==CharIDT.class){
                ls=""+((CharIDT)l).Value;
            }else if(l.getClass()==BooleanIDT.class){
                ls=""+((BooleanIDT)l).Value;
            }else{
                throw new Exception("Variable can't be concatenated");
            }
            if(r.getClass()==StringIDT.class){
                rs=((StringIDT)r).Value;
            }else if(r.getClass()==NumberIDT.class){
                rs=""+((NumberIDT)r).Value;
            }else if(l.getClass()==CharIDT.class){
                rs=""+((CharIDT)r).Value;
            }else if(r.getClass()==BooleanIDT.class){
                rs=""+((BooleanIDT)r).Value;
            }else{
                throw new Exception("Variable can't be concatenated");
            }
            str=ls+rs;
            return new StringIDT(str);
        } else if (expression.getClass() == MathOpNode.class) {

            MathOpNode mathOp = (MathOpNode) expression;
            if(mathOp.left.getClass()!=VariableReferenceNode.class&&mathOp.left.getClass()!=NumericLiteralNode.class&&mathOp.left.getClass()!=MathOpNode.class){
                throw new Exception("Mathing non-number to number");
            }else if(mathOp.right.getClass()!=VariableReferenceNode.class&&mathOp.right.getClass()!=NumericLiteralNode.class&&mathOp.right.getClass()!=MathOpNode.class){
                throw new Exception("Mathing number to non-number");
            }else{
                float number = 0.0F;
                if(mathOp.op.equals(MathOpNode.MathOperations.add)){
                    number=((NumberIDT) Objects.requireNonNull(evaluate(locals, object, mathOp.left))).Value+((NumberIDT) Objects.requireNonNull(evaluate(locals, object, mathOp.right))).Value;
                }else if(mathOp.op.equals(MathOpNode.MathOperations.multiply)){
                    number=((NumberIDT) Objects.requireNonNull(evaluate(locals, object, mathOp.left))).Value*((NumberIDT) Objects.requireNonNull(evaluate(locals, object, mathOp.right))).Value;
                }else if(mathOp.op.equals(MathOpNode.MathOperations.divide)){
                    number=((NumberIDT) Objects.requireNonNull(evaluate(locals, object, mathOp.left))).Value/((NumberIDT) Objects.requireNonNull(evaluate(locals, object, mathOp.right))).Value;
                }else if(mathOp.op.equals(MathOpNode.MathOperations.subtract)){
                    number=((NumberIDT) Objects.requireNonNull(evaluate(locals, object, mathOp.left))).Value-((NumberIDT) Objects.requireNonNull(evaluate(locals, object, mathOp.right))).Value;
                }else if(mathOp.op.equals(MathOpNode.MathOperations.modulo)){
                    number=((NumberIDT) Objects.requireNonNull(evaluate(locals, object, mathOp.left))).Value%((NumberIDT) Objects.requireNonNull(evaluate(locals, object, mathOp.right))).Value;
                }
                result= new NumberIDT(number);
            }

            return result;
        }else if(expression.getClass()== NumericLiteralNode.class){
            return new NumberIDT(((NumericLiteralNode) expression).value);
        }else if(expression.getClass()== VariableReferenceNode.class){
            return findVariable(((VariableReferenceNode) expression).name,locals,object);
        }else if(expression.getClass()== BooleanOpNode.class){
            boolean bool=false;
            BooleanOpNode boolOp=(BooleanOpNode)expression;

            if(boolOp.op.equals(BooleanOpNode.BooleanOperations.or)){
                bool=((BooleanIDT) Objects.requireNonNull(evaluate(locals, object, boolOp.left))).Value||((BooleanIDT) Objects.requireNonNull(evaluate(locals, object, boolOp.right))).Value;
            }else if(boolOp.op.equals(BooleanOpNode.BooleanOperations.and)){
                bool=((BooleanIDT) Objects.requireNonNull(evaluate(locals, object, boolOp.left))).Value&&((BooleanIDT) Objects.requireNonNull(evaluate(locals, object, boolOp.right))).Value;
            }
            return new BooleanIDT(bool);
        }else if(expression.getClass()== BooleanLiteralNode.class){
            return new BooleanIDT(((BooleanLiteralNode) expression).value);
        }else if(expression.getClass()== CompareNode.class){
            CompareNode boolOp=(CompareNode) expression;
            if(boolOp.left.getClass()!=VariableReferenceNode.class&&boolOp.left.getClass()!=NumericLiteralNode.class){
                throw new Exception("Comparing non-number to number");
            }else if(boolOp.right.getClass()!=VariableReferenceNode.class&&boolOp.right.getClass()!=NumericLiteralNode.class){
                throw new Exception("Comparing number to non-number");
            }
            float l=0.0F;
            float r=0.0F;
            if(boolOp.left.getClass()==VariableReferenceNode.class){
                l=((NumberIDT)findVariable(((VariableReferenceNode) boolOp.left).name,locals,object)).Value;
            }else{
                l=((NumericLiteralNode)boolOp.left).value;
            }
            if(boolOp.right.getClass()==VariableReferenceNode.class){
                r=((NumberIDT)findVariable(((VariableReferenceNode) boolOp.right).name,locals,object)).Value;
            }else{
                r=((NumericLiteralNode)boolOp.right).value;
            }
            boolean bool=false;
            if(boolOp.op.equals(CompareNode.CompareOperations.eq)){
                bool= l==r;
            }else if(boolOp.op== CompareNode.CompareOperations.ge){
                bool=(l>=r);
            }else if(boolOp.op== CompareNode.CompareOperations.le){
                bool=(l<=r);
            }else if(boolOp.op== CompareNode.CompareOperations.gt){
                bool=(l>r);
            }else if(boolOp.op== CompareNode.CompareOperations.lt){
                bool=(l<r);
            }else if(boolOp.op== CompareNode.CompareOperations.ne){
                bool=(l!=r);
            }
            return new BooleanIDT(bool);
        }else if(expression.getClass()== NotOpNode.class){
            return new BooleanIDT(!((BooleanIDT)(Objects.requireNonNull(evaluate(locals, object, ((NotOpNode) expression).left)))).Value);
        }else if(expression.getClass()== StringLiteralNode.class){
            return new StringIDT(((StringLiteralNode) expression).value);
        }else if(expression.getClass()== CharLiteralNode.class){
            return new CharIDT(((CharLiteralNode) expression).value);
        }else if(expression.getClass()==NewNode.class){
            return findConstructorAndRunIt(object,locals,(NewNode)expression);
        }else if(expression.getClass()==MethodCallExpressionNode.class){
            MethodCallStatementNode mc=new MethodCallStatementNode((MethodCallExpressionNode) expression);
            return findMethodForMethodCallAndRunIt(object,locals,mc).getFirst();
        }
        return null;
    }

    //              Utility Methods

    /**
     * Used when trying to find a match to a method call. Given a method declaration, does it match this methoc call?
     * We double check with the parameters, too, although in theory JUST checking the declaration to the call should be enough.
     *
     * Match names, parameter counts (both declared count vs method call and declared count vs value list), return counts.
     * If all of those match, consider the types (use TypeMatchToIDT).
     * If everything is OK, return true, else return false.
     * Note - if m is a built-in and isVariadic is true, skip all of the parameter validation.
     * @param m - the method declaration we are considering
     * @param mc - the method call we are trying to match
     * @param parameters - the parameter values for this method call
     * @return does this method match the method call?
     */
    private boolean doesMatch(MethodDeclarationNode m, MethodCallStatementNode mc, List<InterpreterDataType> parameters) {
        return true;
    }

    /**
     * Very similar to DoesMatch() except simpler - there are no return values, the name will always match.
     * @param c - a particular constructor
     * @param mc - the method call
     * @param parameters - the parameter values
     * @return does this constructor match the method call?
     */
    private boolean doesConstructorMatch(ConstructorNode c, MethodCallStatementNode mc, List<InterpreterDataType> parameters) {
        return true;
    }

    /**
     * Used when we call a method to get the list of values for the parameters.
     *
     * for each parameter in the method call, call Evaluate() on the parameter to get an IDT and add it to a list
     * @param object - the current object
     * @param locals - the local variables
     * @param mc - a method call
     * @return the list of method values
     */
    private List<InterpreterDataType> getParameters(Optional<ObjectIDT> object, HashMap<String,InterpreterDataType> locals, MethodCallStatementNode mc) throws Exception {
        List<InterpreterDataType> returns = new ArrayList<>();
        for(ExpressionNode expression: mc.parameters){
            returns.add(evaluate(locals,object,expression));
        }
        return returns;
    }

    /**
     * Used when we have an IDT and we want to see if it matches a type definition
     * Commonly, when someone is making a function call - do the parameter values match the method declaration?
     *
     * If the IDT is a simple type (boolean, number, etc) - does the string type match the name of that IDT ("boolean", etc)
     * If the IDT is an object, check to see if the name matches OR the class has an interface that matches
     * If the IDT is a reference, check the inner (refered to) type
     * @param type the name of a data type (parameter to a method)
     * @param idt the IDT someone is trying to pass to this method
     * @return is this OK?
     */
    private boolean typeMatchToIDT(String type, InterpreterDataType idt) {
        throw new RuntimeException("Unable to resolve type " + type);
    }

    /**
     * Find a method in an object that is the right match for a method call (same name, parameters match, etc. Uses doesMatch() to do most of the work)
     *
     * Given a method call, we want to loop over the methods for that class, looking for a method that matches (use DoesMatch) or throw
     * @param object - an object that we want to find a method on
     * @param mc - the method call
     * @param parameters - the parameter value list
     * @return a method or throws an exception
     */
    private MethodDeclarationNode getMethodFromObject(ObjectIDT object, MethodCallStatementNode mc, List<InterpreterDataType> parameters) {
        throw new RuntimeException("Unable to resolve method call " + mc);
    }

    /**
     * Find a class, given the name. Just loops over the TranNode's classes member, matching by name.
     *
     * Loop over each class in the top node, comparing names to find a match.
     * @param name Name of the class to find
     * @return either a class node or empty if that class doesn't exist
     */
    private Optional<ClassNode> getClassByName(String name) {
        for(ClassNode classy:top.Classes){
            if(classy.name.equals(name)){
                return Optional.of(classy);
            }
        }
        return Optional.empty();
    }

    /**
     * Given an execution environment (the current object, the current local variables), find a variable by name.
     *
     * @param name  - the variable that we are looking for
     * @param locals - the current method's local variables
     * @param object - the current object (so we can find members)
     * @return the IDT that we are looking for or throw an exception
     */
    private InterpreterDataType findVariable(String name, HashMap<String,InterpreterDataType> locals, Optional<ObjectIDT> object) {
        InterpreterDataType variable= locals.get(name);

        return variable;
    }

    /**
     * Given a string (the type name), make an IDT for it.
     *
     * @param type The name of the type (string, number, boolean, character). Defaults to ReferenceIDT if not one of those.
     * @return an IDT with default values (0 for number, "" for string, false for boolean, ' ' for character)
     */
    private InterpreterDataType instantiate(String type) {
        switch (type) {
            case "string":
                return new StringIDT(null);
            case "number":
                return new NumberIDT(0.0F);
            case "char":
                return new CharIDT(' ');
            case "boolean":
                return new BooleanIDT(false);
            default:
                return new ReferenceIDT();
        }
    }
}
