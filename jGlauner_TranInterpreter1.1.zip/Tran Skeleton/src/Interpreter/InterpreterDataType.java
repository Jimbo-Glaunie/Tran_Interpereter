package Interpreter;

public interface InterpreterDataType {
    public void Assign(InterpreterDataType in);
}

