import java.io.IOException;
import java.util.*;
import java.lang.String;

import static java.lang.Character.*;

public class Lexer {

    private LinkedList<Token> retVal = new LinkedList<Token>();

    private int prevIndent=0;

    private int currentIndent=0;

    private HashSet<String> keywords = new HashSet<String>();

    private final String input;

    private final TextManager textMan;

    private int line = 1;

    private int column = 0;

    private int indentLevel = 0;

    public Lexer(String input) {
        this.input = input.replaceAll("    ","\t").replaceAll("\r","");
        this.textMan = new TextManager(this.input);
        keywords.add("false");
        keywords.add("true");
        keywords.add("if");
        keywords.add("else");
        keywords.add("class");
        keywords.add("interface");
        keywords.add("loop");
        keywords.add("accessor");
        keywords.add("mutator");
        keywords.add("implements");
        keywords.add("private");
        keywords.add("shared");
        keywords.add("construct");
        keywords.add("new");
        keywords.add("or");
        keywords.add("and");
    }

    public Token parseWord(char C)throws SyntaxErrorException{
        String currentWord=""+C;
        while(isLetter(textMan.peekCharacter())){
            currentWord+=textMan.getCharacter();
        }
        column++;

        if(keywords.contains(currentWord)){
            return (new Token(Token.TokenTypes.valueOf(currentWord.toUpperCase()), line, column, currentWord));
        }else {
            return (new Token(Token.TokenTypes.WORD, line, column, currentWord));
        }
    }

    public Token parsePunctuation(char C) throws SyntaxErrorException{
        String punc = "" + C;
        switch (C) {
            case '\n':
                int lineTemp=line;
                int columnTemp=column+1;
                column = 0;
                indentLevel=0;
                line++;
                return (new Token(Token.TokenTypes.NEWLINE, lineTemp, columnTemp, ""));
            case '=':
                if (textMan.peekCharacter() == '=') {
                    column++;
                    punc += textMan.getCharacter();
                    return (new Token(Token.TokenTypes.EQUAL, line, column, punc));
                } else {
                    column++;
                    return (new Token(Token.TokenTypes.ASSIGN, line, column, punc));
                }

            case '>':
                if (textMan.peekCharacter() == '=') {
                    column++;
                    punc += textMan.getCharacter();
                    return (new Token(Token.TokenTypes.GREATERTHANEQUAL, line, column, punc));
                } else {
                    column++;
                    return (new Token(Token.TokenTypes.GREATERTHAN, line, column, punc));
                }

            case '<':
                if (textMan.peekCharacter() == '=') {
                    column++;
                    punc += textMan.getCharacter();
                    return (new Token(Token.TokenTypes.LESSTHANEQUAL, line, column, punc));
                } else {
                    column++;
                    return (new Token(Token.TokenTypes.LESSTHAN, line, column, punc));
                }

            case '!':
                if (textMan.peekCharacter() == '=') {
                    punc += textMan.getCharacter();
                    column++;
                    return (new Token(Token.TokenTypes.NOTEQUAL, line, column, punc));
                } else {
                    column++;
                    return (new Token(Token.TokenTypes.NOT, line, column, punc));
                }

            case '\t':
                while(textMan.peekCharacter()=='\t'){
                    currentIndent++;
                    textMan.getCharacter();
                }

                if(currentIndent<prevIndent){
                    for(int i=0;i<prevIndent-currentIndent;i++){
                        column++;
                        retVal.add(new Token(Token.TokenTypes.DEDENT,line,column,""));
                    }
                }

                prevIndent=currentIndent;
                currentIndent=0;
                if(textMan.peekCharacter()=='\n'){
                    textMan.getCharacter();
                    return new Token(Token.TokenTypes.NEWLINE, line, column, punc);
                }
                return new Token(Token.TokenTypes.INDENT,line,column,"");
            case ':':
                column++;
                return (new Token(Token.TokenTypes.COLON, line, column, punc));
            case '(':
                column++;
                return (new Token(Token.TokenTypes.LPAREN, line, column, punc));
            case ')':
                column++;
                return (new Token(Token.TokenTypes.RPAREN, line, column, punc));
            case '.':
                if (isDigit(textMan.peekCharacter())) {
                    while (isDigit(textMan.peekCharacter())) {
                        punc += textMan.getCharacter();
                    }
                    column++;
                    return (new Token(Token.TokenTypes.NUMBER, line, column, punc));
                } else {
                    column++;
                    return (new Token(Token.TokenTypes.DOT, line, column, punc));
                }

            case ',':
                column++;
                return (new Token(Token.TokenTypes.COMMA, line, column, punc));
            case '+':
                column++;
                return (new Token(Token.TokenTypes.PLUS, line, column, punc));
            case '-':
                column++;
                return (new Token(Token.TokenTypes.MINUS, line, column, punc));
            case '*':
                column++;
                return (new Token(Token.TokenTypes.TIMES, line, column, punc));
            case '/':
                column++;
                return (new Token(Token.TokenTypes.DIVIDE, line, column, punc));
            case '%':
                column++;
                return (new Token(Token.TokenTypes.MODULO, line, column, punc));
            case'\"':
                column++;
                punc="";
                while(textMan.peekCharacter()!='\"'){
                    punc+=textMan.getCharacter();
                    if(textMan.isAtEnd()){
                        throw new SyntaxErrorException("unfinished QUOTEDSTRING",line,column);
                    }
                }
                if(textMan.peekCharacter()=='\"') {
                    textMan.getCharacter();
                }
                return(new Token(Token.TokenTypes.QUOTEDSTRING, line, column, punc));
            case'\'':
                if(!textMan.isAtEnd()){
                    punc=""+textMan.getCharacter();
                }
                if(!textMan.isAtEnd()) {
                    if (textMan.peekCharacter() == '\'') {
                        textMan.getCharacter();
                    } else {
                        throw new SyntaxErrorException("unfinished or bad QUOTEDCHARACTER", line, textMan.getPosition());
                    }
                }else{
                    throw new SyntaxErrorException("unfinished or bad QUOTEDCHARACTER",line,textMan.getPosition());
                }
                column++;
                return(new Token(Token.TokenTypes.QUOTEDCHARACTER, line, column, punc));
            case'&':
                if(textMan.getCharacter()=='&'){
                    column++;
                    return(new Token(Token.TokenTypes.AND, line, column, "&&"));
                }else{
                    throw new SyntaxErrorException("unfinished AND",line,textMan.getPosition());
                }
            case'|':
                if(textMan.getCharacter()=='|'){
                    column++;
                    return(new Token(Token.TokenTypes.OR, line, column, "||"));
                }else{
                    throw new SyntaxErrorException("unfinished OR",line,textMan.getPosition());
                }
            case '{':
                while(textMan.peekCharacter()!='}'){
                    textMan.getCharacter();
                    if(textMan.isAtEnd()){
                        throw new SyntaxErrorException("unfinished comment",line,column);
                    }
                }
                textMan.getCharacter();
                return new Token(null,0,0,"");
            case '}':
                throw new SyntaxErrorException("unstarted comment",line,column);
            case '\r':

            default:
                throw new SyntaxErrorException("unrecognized symbol",line,textMan.getPosition());

        }
    }

    public Token parseNumber(char c)throws SyntaxErrorException{
        String num=""+c;
        int decimal = 0;
        while(isDigit(textMan.peekCharacter())||textMan.peekCharacter()=='.'){
            if(textMan.peekCharacter()=='.'){
                if(decimal>0){
                    throw new SyntaxErrorException("decimalPoints>1",line, textMan.getPosition());
                }
                decimal++;
            }
            num+=textMan.getCharacter();
        }
        column++;
        return(new Token(Token.TokenTypes.NUMBER, line, column,num));

    }


        public LinkedList<Token> Lex(){

            try {
                do {
                    char c = textMan.getCharacter();
                    if (isLetter(c)) {
                        retVal.add(parseWord(c));
                    } else if (isDigit(c)) {
                        retVal.add(parseNumber(c));
                    } else if(c!=' '){
                        retVal.add(parsePunctuation(c));
                    }
                    if(!retVal.isEmpty()){
                        if(retVal.getLast().getType()==null){
                            retVal.removeLast();
                        }
                    }
                } while (!textMan.isAtEnd());
            } catch (Exception e) {
                System.out.println("Exception in Lexer: " + e.toString());
            }
            return retVal;
        }

    }

